import LeaderboardIcon from '@mui/icons-material/Leaderboard';

export const mainMenu = [

  {
    id: 'dashboard',
    name: 'Dashboard',
    url: "/leads/dashboard/",
    icon: <LeaderboardIcon></LeaderboardIcon>,

  },








];